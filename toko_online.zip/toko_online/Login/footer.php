<footer class="bg-primary text-white text-center pb-6">
      <p>Created With <i class="fa-solid fa-heart"></i></p>
    </footer>

    <style>
       footer {
        position: fixed; 
        bottom: 0; 
        width: 100%; 
        background-color: #333; /* Warna latar belakang footer */
        color: #fff; /* Warna teks */
        text-align: center; /* Teks rata tengah */
        padding: 0px 0; /* Padding atas dan bawah */
        height: 25px;
        font-family: "Poppins", sans-serif;
    
    }
    </style>

